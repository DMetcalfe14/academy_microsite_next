// Initialize Pipwerks SCORM API Wrapper
var scorm = pipwerks.SCORM;
var lmsConnected = false;

// Connect to LMS
window.onload = function () {
    lmsConnected = scorm.init();
    if (lmsConnected) {
        console.log("Connected to LMS");
        // Optionally retrieve learner name
        var learnerName = scorm.get("cmi.core.student_name");
        console.log("Learner Name:", learnerName);
    } else {
        console.error("Failed to connect to LMS");
    }
};

// Mark course as completed and disconnect
function completeCourse() {
    if (lmsConnected) {
        scorm.set("cmi.core.lesson_status", "completed");
        scorm.save();
        alert("Course marked as completed!");
        scorm.quit();
    } else {
        alert("Not connected to LMS");
    }
}

// Ensure proper termination on window unload
window.onunload = function () {
    if (lmsConnected) {
        scorm.quit();
    }
};
